from Functions import *

#Domain
L = 100
#dz_ref = 0.1
dz_ref = 0.05
Nz_ref = int(L/dz_ref)
Z = np.linspace(0, L, Nz_ref)
#Problem parameters
K = 1e-3 + 2e-2 * Z / 7 * np.exp(- Z / 7) + 5e-2 * (L - Z) / 10 * np.exp(-((L - Z) / 10)) #Diffusivity
kw = 6.97e-5 #Mass transfer coefficient
C0 = np.zeros(Nz_ref) #Initial DIC concentration

#Convergence test for time
Tmax = 10 * 24 * 3600 #10 day simulation time in seconds
#Reference solution
dt_ref = 1e-4 * 3600 #Reference timestep, 10^-4 hours
Nt_ref = int(Tmax/dt_ref)
C_eq = 5060 * 415e-6 * np.ones(Nt_ref+1) #CO2 concentration
C_ref = iteratorReturnLastTime(C0, Nt_ref, dt_ref, dz_ref, K, kw, C_eq)

M1_ref = simps(C_ref * Z, x = Z) #Reference first moment
M2_ref = simps(C_ref * Z**2, x = Z) #Reference second moment

#Test timesteps:
#dts = 3600 * np.array([0.001, 0.005, 0.01, 0.05, 0.1, 1, 2, 4, 8, 16, 48])
dts = np.array([0.0025,0.005,0.01,0.05,0.1,0.2,1,2,4,8,10,20,40])*3600

M1_errorT = np.zeros(len(dts))
M2_errorT = np.zeros(len(dts))
RMS_errorT = np.zeros(len(dts))
L2_errorT = np.zeros(len(dts))
for i, dt in enumerate(dts):
    Nt = int(Tmax/dt)
    C_eq = 5060 * 415e-6 * np.ones(Nt+1) #CO2 concentration
    C = iteratorReturnLastTime(C0, Nt, dt, dz_ref, K, kw, C_eq)
    M1_errorT[i] = np.abs(M1_ref - simps(C * Z, x = Z))
    M2_errorT[i] = np.abs(M2_ref - simps(C * Z**2, x = Z))
    RMS_errorT[i] = np.sqrt(np.mean((C - C_ref)**2))
    L2_errorT[i] = np.abs(np.linalg.norm(C_ref) - np.linalg.norm(C))
    
plt.figure(1)
plt.plot(dts/3600, M1_errorT, marker = '.' ,label = "M1", color = "blue")
plt.plot(dts/3600, M2_errorT, marker = '.', label = "M2", color = "red")
plt.plot(dts/3600, (dts/3600)**2, linestyle = "--", label = r"$\sim \Delta t^2$", color = 'black')
plt.plot(dts/3600, dts/3600, linestyle = "-.", label = r"$\sim \Delta t$", color = 'black')
plt.xscale("log")
plt.yscale("log")
plt.xlabel("Timestep [h]")
plt.ylabel("Absolute Error")
plt.legend()
plt.show()

plt.figure(2)
plt.plot(dts/3600, RMS_errorT, marker = '.' ,label = "RMS", color = "blue")
plt.plot(dts/3600, L2_errorT, marker = '.' ,label = "L2", color = "red")
plt.plot(dts/3600, (dts/3600)**2, linestyle = "--", label = r"$\sim \Delta t^2$", color = 'black')
plt.plot(dts/3600, dts/3600, linestyle = "-.", label = r"$\sim \Delta t$", color = 'black')
plt.xlabel("Timestep [h]")
plt.ylabel("Absolute Error")
plt.xscale("log")
plt.yscale("log")
plt.legend()
plt.show()

# #Convergence test for gridspacing
# #Reference solution
# dt_ref = 3600 * 0.001 #Reference timestep
# Nt_ref = int(Tmax/dt_ref)
# dz_ref = 0.01
# Nz_ref = int(L/dz_ref)
# Z = np.linspace(0, L, Nz_ref)
# K = 1e-3 + 2e-2 * Z / 7 * np.exp(- Z / 7) + 5e-2 * (L - Z) / 10 * np.exp(-((L - Z) / 10)) #Diffusivity
# C0 = np.zeros(Nz_ref) #Initial DIC concentration
# C_eq = 5060 * 415e-6 * np.ones(Nt_ref+1) #CO2 concentration
# C_ref = iteratorReturnLastTime(C0, Nt_ref, dt_ref, dz_ref, K, kw, C_eq)

# M1_ref = simps(C_ref * Z, x = Z) #Reference first moment
# M2_ref = simps(C_ref * Z**2, x = Z) #Reference second moment

# #Test gridspacing:
# dzs = np.array([0.05, 0.1, 0.5, 1, 2, 5, 10])
# M1_errorZ = np.zeros(len(dzs))
# M2_errorZ = np.zeros(len(dzs))
# RMS_errorZ = np.zeros(len(dzs))
# L2_errorZ = np.zeros(len(dzs))
# for i, dz in enumerate(dzs):
#     Nz = int(L/dz)
#     Z = np.linspace(0, L, Nz)
#     K = 1e-3 + 2e-2 * Z / 7 * np.exp(- Z / 7) + 5e-2 * (L - Z) / 10 * np.exp(-((L - Z) / 10)) #Diffusivity
#     C0 = np.zeros(Nz) #Initial DIC concentration
#     C = iteratorReturnLastTime(C0, Nt_ref, dt_ref, dz, K, kw, C_eq)
#     M1_errorZ[i] = np.abs(M1_ref - simps(C * Z, x = Z))
#     M2_errorZ[i] = np.abs(M2_ref - simps(C * Z**2, x = Z))
#     Nskip = int((Nz_ref-1)/(Nz-1))
#     RMS_errorZ[i] = np.sqrt(np.mean((C - C_ref[::Nskip])**2))
#     L2_errorZ[i] = np.abs(np.linalg.norm(C_ref) - np.linalg.norm(C))

# plt.figure(3)
# plt.plot(dzs, M1_errorZ, marker = '.' ,label = "M1", color = "blue")
# plt.plot(dzs, M2_errorZ, marker = '.', label = "M2", color = "red")
# plt.plot(dzs, dzs**2, linestyle = "--", label = r"$\sim \Delta z^2$", color = 'black')
# plt.plot(dzs, dzs, linestyle = "-.", label = r"$\sim \Delta z$", color = 'black')
# plt.xscale("log")
# plt.yscale("log")
# plt.legend()
# plt.show()

# plt.figure(4)
# plt.plot(dzs, RMS_errorZ, marker = '.' ,label = "RMS", color = "blue")
# plt.plot(dzs, L2_errorZ, marker = '.' ,label = "L2", color = "red")
# plt.plot(dzs, dzs**2, linestyle = "--", label = r"$\sim \Delta z^2$", color = 'black')
# plt.xscale("log")
# plt.yscale("log")
# plt.show()
